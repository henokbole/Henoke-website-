export const categoryInfos = [
  {
    title: "Electronics",
    name: "electronics",
    imgLink: "https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_t.png",
  },
  {
    title: "Discover fashion trends",
    name: "women's clothing",
    imgLink: "https://fakestoreapi.com/img/71HblAHs5xL._AC_UY879_-2t.png",
  },
  {
    title: "Men's Clothing",
    name: "men's clothing",
    imgLink: "https://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_t.png",
  },
  {
    title: "Jewelery",
    name: "jewelery",
    imgLink:
      "https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_t.png",
  },
];
