// Import the functions you need from the SDKs you need
import firebase from "firebase/compat/app";
// authentication
import { getAuth } from "firebase/auth";
import "firebase/compat/firestore";
import "firebase/compat/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCcXsK8ChZqePdoXLbZ-NcKSmE6qV2tCto",
  authDomain: "e-clone-85cde.firebaseapp.com",
  projectId: "e-clone-85cde",
  storageBucket: "e-clone-85cde.firebasestorage.app",
  messagingSenderId: "492622447852",
  appId: "1:492622447852:web:cc5d7dceb5a68e42fbd1c9",
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = app.firestore();
