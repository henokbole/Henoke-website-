import { defineConfig } from "vite";

// https://vitejs.dev/config/
export default defineConfig({
  base: "/netflix_clone/",
});
